from paquete import modulo

modulo.start()